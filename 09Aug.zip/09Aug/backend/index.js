const express = require('express');
const app = express();
const cors = require('cors');

app.use(express.json());
app.use(cors());

// In-memory storage
let products = [];
let currentId = 1;

/**
 * CREATE Product
 */
app.post('/products', (req, res) => {
    const { name, price, category } = req.body;

    if (!name || !price) {
        return res.status(400).json({ message: 'Name and price are required' });
    }

    const newProduct = {
        id: currentId++,
        name,
        price,
        category: category || 'General'
    };

    products.push(newProduct);

    res.status(201).json(newProduct);
});

/**
 * READ All Products
 */
app.get('/products', (req, res) => {
    res.json(products);
});

/**
 * READ Single Product
 */
app.get('/products/:id', (req, res) => {
    const id = parseInt(req.params.id);

    const product = products.find(p => p.id === id);

    if (!product) {
        return res.status(404).json({ message: 'Product not found' });
    }

    res.json(product);
});

/**
 * UPDATE Product
 */
app.put('/products/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const { name, price, category } = req.body;

    const product = products.find(p => p.id === id);

    if (!product) {
        return res.status(404).json({ message: 'Product not found' });
    }

    if (name) product.name = name;
    if (price) product.price = price;
    if (category) product.category = category;

    res.json(product);
});

/**
 * DELETE Product
 */
app.delete('/products/:id', (req, res) => {
    const id = parseInt(req.params.id);

    const index = products.findIndex(p => p.id === id);

    if (index === -1) {
        return res.status(404).json({ message: 'Product not found' });
    }

    const deletedProduct = products.splice(index, 1);

    res.json({ message: 'Product deleted', product: deletedProduct });
});


// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});