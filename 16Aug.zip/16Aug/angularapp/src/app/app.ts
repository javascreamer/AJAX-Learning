import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import axios from 'axios';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
 
    getProducts(){
        
         axios.get("http://localhost:3000/products").then(
          response => console.log(response)
         )
         
    }


}
